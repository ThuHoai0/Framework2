import { useParams } from "react-router-dom";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "../config/axios.ts";
import { IProduct } from "../interface/product.ts";
import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { message } from "antd";
import { useNavigate } from "react-router-dom";
import { ICartItem } from "../interface/cart.ts";

export function ProductDetails() {
    const { id } = useParams<{ id: string }>();
    const [quantity, setQuantity] = useState(1);
    const [mainImage, setMainImage] = useState<string>("");
    const navigate = useNavigate();
    const { addToCart } = useCart();

    const { data: product, isLoading, isError } = useQuery<IProduct>({
        queryKey: ["product", id],
        queryFn: async () => {
            try {
                const { data } = await api.get(`http://localhost:3000/products/${id}`);
                setMainImage(data.images);
                return data;
            } catch (error) {
                console.log(error);
                throw error;
            }
        },
    });

    const handleAddToCart = () => {
        const user = JSON.parse(localStorage.getItem("user") || "{}");
        if (!user || !user.id) {
            message.warning("Vui lòng đăng nhập để thêm sản phẩm vào giỏ hàng");
            navigate("/login");
            return;
        }

        if (product) {
            const cartItem: ICartItem = {
                id: product.id,
                name: product.name,
                price: product.price,
                images: product.images,
                quantity: 1,
                categoryID: product.categoryID
            };
            addToCart(cartItem);
            message.success("Đã thêm sản phẩm vào giỏ hàng");
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gray-100 p-10">
                <div className="flex items-center justify-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-500"></div>
                </div>
            </div>
        );
    }

    if (isError || !product) {
        return (
            <div className="min-h-screen bg-gray-100 p-10">
                <div className="text-center py-20">
                    <h2 className="text-2xl font-bold text-red-500 mb-4">Không tìm thấy sản phẩm</h2>
                    <Link to="/" className="text-blue-500 hover:underline">
                        Quay lại trang chủ
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 py-8">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-sm mb-8">
                <Link to="/" className="hover:text-red-500">Account</Link>
                <span>/</span>
                <Link to="/gaming" className="hover:text-red-500">Gaming</Link>
                <span>/</span>
                <span className="text-gray-500">{product.name}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Left Column - Images */}
                <div>
                    <div className="flex gap-4">
                        {/* Thumbnails */}
                        <div className="flex flex-col gap-4">
                            <img
                                src="https://i.pinimg.com/736x/d7/13/d8/d713d81f411e557305794ea8094aaf8c.jpg" 
                                className={`w-24 h-24 object-cover rounded-md cursor-pointer hover:border-2 hover:border-red-500 ${
                                    mainImage === "https://i.pinimg.com/736x/d7/13/d8/d713d81f411e557305794ea8094aaf8c.jpg" ? 'border-2 border-red-500' : ''
                                }`}
                                onClick={() => setMainImage("https://i.pinimg.com/736x/d7/13/d8/d713d81f411e557305794ea8094aaf8c.jpg")}
                            />
                            <img
                                src="https://i.pinimg.com/736x/43/61/09/4361091dd491bacbbcdbaa0be7a2d2be.jpg" 
                                className={`w-24 h-24 object-cover rounded-md cursor-pointer hover:border-2 hover:border-red-500 ${
                                    mainImage === "https://i.pinimg.com/736x/43/61/09/4361091dd491bacbbcdbaa0be7a2d2be.jpg" ? 'border-2 border-red-500' : ''
                                }`}
                                onClick={() => setMainImage("https://i.pinimg.com/736x/43/61/09/4361091dd491bacbbcdbaa0be7a2d2be.jpg")}
                            />
                            <img
                                src="https://i.pinimg.com/736x/46/e9/64/46e9646db20d236518c3ca40d7f64acc.jpg" 
                                className={`w-24 h-24 object-cover rounded-md cursor-pointer hover:border-2 hover:border-red-500 ${
                                    mainImage === "https://i.pinimg.com/736x/46/e9/64/46e9646db20d236518c3ca40d7f64acc.jpg" ? 'border-2 border-red-500' : ''
                                }`}
                                onClick={() => setMainImage("https://i.pinimg.com/736x/46/e9/64/46e9646db20d236518c3ca40d7f64acc.jpg")}
                            />
                            <img
                                src="https://i.pinimg.com/736x/1f/2f/f4/1f2ff41d0c1186d882d322ec3cb67a15.jpg"  
                                className={`w-24 h-24 object-cover rounded-md cursor-pointer hover:border-2 hover:border-red-500 ${
                                    mainImage === "https://i.pinimg.com/736x/1f/2f/f4/1f2ff41d0c1186d882d322ec3cb67a15.jpg" ? 'border-2 border-red-500' : ''
                                }`}
                                onClick={() => setMainImage("https://i.pinimg.com/736x/1f/2f/f4/1f2ff41d0c1186d882d322ec3cb67a15.jpg")}
                            />
                        </div>
                        {/* Main Image */}
                        <div className="flex-1">
                            <img 
                                src={mainImage || "/src/assets/Product-details/1.png"} 
                                alt={product.name} 
                                className="w-full h-[500px] object-cover rounded-lg"
                            />
                        </div>
                    </div>
                </div>

                {/* Right Column - Product Info */}
                <div>
                    <h1 className="text-2xl font-bold mb-2">{product.name}</h1>
                    <div className="flex items-center gap-2 mb-4">
                        <div className="flex text-yellow-400">
                            {[...Array(5)].map((_, i) => (
                                <span key={i}>★</span>
                            ))}
                        </div>
                        <span className="text-gray-500">(150 Reviews)</span>
                        <span className="text-green-500 ml-4">In Stock</span>
                    </div>
                    <div className="text-2xl font-bold mb-6">
                        <span className="text-black">${product.price}</span>
                    </div>
                    <p className="text-gray-600 mb-6">
                        PlayStation 5 Controller Skin High quality vinyl with air channel adhesive for easy bubble free install & mess free removal Pressure sensitive.
                    </p>

                    <div className="mb-6">
                        <p className="font-semibold mb-2">Colours:</p>
                        <div className="flex gap-2">
                            <button className="w-8 h-8 rounded-full bg-white border-2 border-red-500"></button>
                            <button className="w-8 h-8 rounded-full bg-red-500"></button>
                        </div>
                    </div>

                    <div className="mb-6">
                        <p className="font-semibold mb-2">Size:</p>
                        <div className="flex gap-2">
                            {['XS', 'S', 'M', 'L', 'XL'].map((size) => (
                                <button 
                                    key={size}
                                    className="w-10 h-10 border rounded-md hover:border-red-500 hover:text-red-500"
                                >
                                    {size}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="flex items-center gap-4 mb-6">
                        <div className="flex items-center border rounded-md">
                            <button
                                className="px-4 py-2 hover:text-red-500"
                                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                            >
                                -
                            </button>
                            <span className="px-4 py-2">{quantity}</span>
                            <button
                                className="px-4 py-2 hover:text-red-500"
                                onClick={() => setQuantity(quantity + 1)}
                            >
                                +
                            </button>
                        </div>
                        <button 
                            className="flex-1 bg-red-500 text-white py-2 px-6 rounded-md hover:bg-red-600"
                            onClick={handleAddToCart}
                        >
                            Buy Now
                        </button>
                        <button className="p-2 border rounded-md hover:border-red-500">
                            <img src="/src/assets/Fill Heart.png" alt="Wishlist" className="w-6 h-6" />
                        </button>
                    </div>

                    {/* Delivery Info */}
                    <div className="space-y-4 border rounded-lg p-4">
                        <div className="flex items-center gap-4">
                            <img src="/src/assets/icon-delivery.png" alt="Free Delivery" className="w-8 h-8" />
                            <div>
                                <h3 className="font-semibold">Free Delivery</h3>
                                <p className="text-sm text-gray-500">Enter your postal code for Delivery Availability</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <img src="/src/assets/Icon-return.png" alt="Return Delivery" className="w-8 h-8" />
                            <div>
                                <h3 className="font-semibold">Return Delivery</h3>
                                <p className="text-sm text-gray-500">Free 30 Days Delivery Returns. Details</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Related Products */}
            <div className="mt-16">
                <div className="flex items-center gap-3 mb-8">
                    <span className="bg-red-500 h-6 w-2 rounded"></span>
                    <p className="text-red-500 font-semibold">Related Item</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    {[1, 2, 3, 4].map((item) => (
                        <div key={item} className="group">
                            <div className="relative h-[300px] bg-[#F5F5F5] rounded-lg mb-4">
                                <div className="absolute top-2 left-2">
                                    <span className="bg-red-500 text-white text-sm px-3 py-1 rounded">
                                        -40%
                                    </span>
                                </div>
                                <div>
                                    <img 
                                        src={product.images} 
                                        alt="Related product" 
                                        className="w-full h-[250px] object-contain p-5"
                                    />
                                </div>
                                <div className="absolute top-2 right-2 flex flex-col gap-2">
                                    <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                        <img src="/src/assets/Fill Heart.png" alt="Wishlist" className="w-5 h-5" />
                                    </button>
                                    <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                        <img src="/src/assets/Fill Eye.png" alt="Quick view" className="w-5 h-5" />
                                    </button>
                                </div>
                                {/* Add to Cart Button - appears on hover */}
                                <div className="absolute bottom-2 left-2 right-2 opacity-0 group-hover:opacity-100 transition-all duration-300">
                                    <button className="w-full bg-black text-white py-2 rounded-md hover:bg-gray-800 transition-colors">
                                        Add To Cart
                                    </button>
                                </div>
                            </div>

                            <div>
                                <h3 className="font-medium text-lg mb-2">{product.name}</h3>
                            </div>

                            <div className="flex items-center gap-2 mb-2">
                                <span className="text-red-500 font-semibold">$120</span>
                                <span className="text-gray-500 line-through">$160</span>
                            </div>

                            <div className="flex items-center gap-1">
                                <div className="flex text-yellow-400">
                                    {[...Array(5)].map((_, i) => (
                                        <span key={i}>★</span>
                                    ))}
                                </div>
                                <span className="text-gray-500">(88)</span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

