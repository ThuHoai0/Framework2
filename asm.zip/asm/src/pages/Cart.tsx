import { Link } from "react-router-dom";
import { Button, message } from "antd";
import { DeleteOutlined, MinusOutlined, PlusOutlined } from "@ant-design/icons";
import { useCart } from "../context/CartContext";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "../config/axios";

const Cart = () => {
    const { cart, updateQuantity, removeFromCart, clearCart } = useCart();
    const queryClient = useQueryClient();

    const createOrderMutation = useMutation({
        mutationFn: async (orderData) => {
            const { data } = await api.post("http://localhost:3000/orders", orderData);
            return data;
        },
        onSuccess: () => {
            clearCart();
            message.success("Đặt hàng thành công!");
            queryClient.invalidateQueries({ queryKey: ["orders"] });
        },
        onError: () => {
            message.error("Đặt hàng thất bại. Vui lòng thử lại sau!");
        }
    });

    const handleCheckout = () => {
        const user = JSON.parse(localStorage.getItem("user") || "{}");
        
        const orderData = {
            userId: user.id || 0,
            userEmail: user.email || "guest",
            items: cart.items,
            total: cart.total,
            orderDate: new Date().toISOString(),
            status: "pending"
        };
        
        createOrderMutation.mutate(orderData);
    };

    return (
        <div className="min-h-screen bg-gray-100 py-8 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <h1 className="text-3xl font-bold text-gray-900 mb-8">Giỏ hàng của bạn</h1>
                
                {cart.items.length === 0 ? (
                    <div className="text-center py-12">
                        <h2 className="text-xl font-semibold text-gray-600 mb-4">Giỏ hàng trống</h2>
                        <Link to="/">
                            <Button type="primary" size="large">
                                Tiếp tục mua sắm
                            </Button>
                        </Link>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        {/* Cart Items */}
                        <div className="lg:col-span-2">
                            <div className="bg-white rounded-lg shadow-sm">
                                {cart.items.map(item => (
                                    <div key={item.id} className="flex items-center p-4 border-b last:border-b-0">
                                        <div className="w-24 h-24 flex-shrink-0">
                                            <img
                                                src={item.images}
                                                alt={item.name}
                                                className="w-full h-full object-cover rounded-md"
                                            />
                                        </div>
                                        <div className="ml-4 flex-grow">
                                            <h3 className="text-lg font-medium text-gray-900">{item.name}</h3>
                                            <p className="text-lg font-semibold text-red-500 mt-1">
                                                ${Number(item.price).toFixed(2)}
                                            </p>
                                            <div className="flex items-center mt-2">
                                                <button
                                                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                                    className="p-1 border rounded-l-md hover:bg-gray-100"
                                                >
                                                    <MinusOutlined />
                                                </button>
                                                <span className="px-4 py-1 border-t border-b">
                                                    {item.quantity}
                                                </span>
                                                <button
                                                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                                    className="p-1 border rounded-r-md hover:bg-gray-100"
                                                >
                                                    <PlusOutlined />
                                                </button>
                                            </div>
                                        </div>
                                        <button
                                            onClick={() => removeFromCart(item.id)}
                                            className="ml-4 text-gray-400 hover:text-red-500"
                                        >
                                            <DeleteOutlined className="text-xl" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Order Summary */}
                        <div className="lg:col-span-1">
                            <div className="bg-white rounded-lg shadow-sm p-6">
                                <h2 className="text-xl font-semibold text-gray-900 mb-4">Tổng đơn hàng</h2>
                                <div className="space-y-4">
                                    <div className="flex justify-between">
                                        <span className="text-gray-600">Tạm tính</span>
                                        <span className="font-medium">${Number(cart.total).toFixed(2)}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-gray-600">Phí vận chuyển</span>
                                        <span className="font-medium">$0.00</span>
                                    </div>
                                    <div className="border-t pt-4">
                                        <div className="flex justify-between">
                                            <span className="text-lg font-semibold">Tổng cộng</span>
                                            <span className="text-lg font-semibold text-red-500">
                                                ${Number(cart.total).toFixed(2)}
                                            </span>
                                        </div>
                                    </div>
                                    <Button
                                        type="primary"
                                        size="large"
                                        className="w-full mt-6"
                                        onClick={handleCheckout}
                                    >
                                        Thanh toán
                                    </Button>
                                    <Link to="/" className="block text-center mt-4 text-blue-500 hover:underline">
                                        Tiếp tục mua sắm
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Cart;
