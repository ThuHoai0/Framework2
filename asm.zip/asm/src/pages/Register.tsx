import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { message } from "antd";
import { api } from "../config/axios";
import { AxiosError } from "axios";

interface IUser {
  email: string;
  password: string;
}

export function Register() {
    const { register, handleSubmit, formState: { errors }, reset } = useForm<IUser>();
    const navigate = useNavigate();
    
    const mutation = useMutation({
        mutationFn: async (userData: IUser) => {
            const newUserData = {
                ...userData,
                role: 'user'
            }
            const { data } = await api.post('/users', newUserData);
            console.log(data);
            
            return data;
        },
        onSuccess: () => {
            message.success('Đăng ký thành công!');
            reset(); 
            navigate('/login');
        },
        onError: (error: AxiosError<{message?: string}>) => {
            const errorMessage = error.response?.data?.message 
              || error.message 
              || 'Đăng ký không thành công. Vui lòng kiểm tra lại thông tin.';
            message.error(errorMessage);
        }
    });

    const onSubmit = (userData: IUser) => {
        mutation.mutate(userData);
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-white mt-8">
            <div className="flex flex-col md:flex-row w-full h-screen">
                <div className="md:w-1/2 w-full h-full">
                    <img
                        src="/src/assets/login.jpg"
                        alt="Register Illustration"
                        className="object-cover w-full h-full"
                    />
                </div>

                <div className="md:w-1/2 w-full p-6 md:p-14 flex flex-col justify-center">
                    <h1 className="text-2xl md:text-3xl font-bold text-[#1A1A1A] mb-2">
                        Register to Exclusive
                    </h1>
                    <p className="text-[#787878] mb-6 md:mb-10">
                        Enter your details below
                    </p>

                    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-6 md:gap-8">
                        <div className="flex flex-col gap-1">
                            <label htmlFor="email" className="sr-only">Email</label>
                            <input
                                id="email"
                                type="text"
                                placeholder="Email"
                                className="border-b-2 border-[#CCCCCC] pb-3 focus:border-[#1A1A1A] outline-none placeholder-[#787878] text-lg"
                                {...register('email', {
                                    required: 'Email không được để trống',
                                    pattern: {
                                        value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                        message: 'Email sai định dạng'
                                    }
                                })}
                            />
                            {errors.email && <p className='text-red-500 text-sm'>{errors.email.message}</p>}
                        </div>

                        <div className="flex flex-col gap-1">
                            <label htmlFor="password" className="sr-only">Password</label>
                            <input
                                id="password"
                                type="password"
                                placeholder="Password"
                                className="border-b-2 border-[#CCSSCC] pb-3 focus:border-[#1A1A1A] outline-none placeholder-[#787878] text-lg"
                                {...register('password', {
                                    required: 'Mật khẩu không được để trống',
                                    minLength: {
                                        value: 6,
                                        message: 'Mật khẩu phải có ít nhất 6 ký tự'
                                    },
                                    maxLength: {
                                        value: 30,
                                        message: 'Mật khẩu không được quá 30 ký tự'
                                    }
                                })}
                            />
                            {errors.password && <p className='text-red-500 text-sm'>{errors.password.message}</p>}
                        </div>

                        <div className="flex items-center justify-between gap-4">
                            <button 
                                type="submit"
                                className="flex-1 bg-[#DB4444] text-white py-4 rounded-md font-medium hover:bg-[#C93535] transition-colors disabled:opacity-70"
                                disabled={mutation.isPending}
                            >
                                {mutation.isPending ? 'Registering...' : 'Register'}
                            </button>
                            <a href="/login" className="text-[#DB4444] font-medium hover:underline whitespace-nowrap">
                                Already have an account? Login
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}