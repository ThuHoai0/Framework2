import { useQuery } from "@tanstack/react-query";
import { IProduct } from "../interface/product";
import { api } from "../config/axios";
import { useSearchParams } from "react-router-dom";
import { Link } from "react-router-dom";

const SearchProducts = () => {
    const [searchParams] = useSearchParams();
    const keyword = searchParams.get("keyword") || "";

    const { data: products, isLoading } = useQuery<IProduct[]>({
        queryKey: ["products", keyword],
        queryFn: async () => {
            try {
                const { data } = await api.get("http://localhost:3000/products");
                return data.filter((product: IProduct) => 
                    product.name.toLowerCase().includes(keyword.toLowerCase()) ||
                    product.category?.toLowerCase().includes(keyword.toLowerCase())
                );
            } catch (error) {
                console.log(error);
                return [];
            }
        }
    });

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="text-xl">Đang tải dữ liệu...</div>
            </div>
        );
    }

    return (
        <div className="container mx-auto p-6">
            <h1 className="text-2xl font-bold mb-6">
                Kết quả tìm kiếm cho: {keyword}
            </h1>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {products && products.length > 0 ? (
                    products.map((product) => (
                        <div key={product.id} className="p-4 border rounded-lg shadow hover:shadow-lg transition">
                            <Link to={`/product-details/${product.id}`} className="relative block">
                                <img 
                                    src={product.images} 
                                    alt={product.name}
                                    className="w-full h-48 object-cover rounded-lg"
                                />
                                <div className="absolute top-2 right-2 flex gap-2">
                                    <span className="bg-white bg-opacity-75 rounded-full p-1">
                                        <img src="/src/assets/Fill Heart.png" alt="Like" />
                                    </span>
                                    <span className="bg-white bg-opacity-75 rounded-full p-1">
                                        <img src="/src/assets/Fill Eye.png" alt="View" />
                                    </span>
                                </div>
                            </Link>
                            <h2 className="mt-2 font-semibold">{product.name}</h2>
                            <p className="text-red-500 font-bold">{product.price}</p>
                        </div>
                    ))
                ) : (
                    <div className="col-span-full text-center text-gray-500">
                        Không tìm thấy sản phẩm nào
                    </div>
                )}
            </div>
        </div>
    );
};

export default SearchProducts; 