export const Notfound = () => {
    return (
        <>
           <div className="flex flex-col items-center justify-center mt-6 md:mt-12 px-6">
    {/* Điều hướng */}
    <div className="text-gray-600 self-start md:ml-20 text-sm md:text-base">
        <a href="#" className="hover:text-gray-800">Home</a> / 404 Error
    </div>

    {/* Nội dung chính */}
    <div className="min-h-[70vh] flex items-center justify-center text-center p-4">
        <div className="max-w-2xl">
            <h1 className="text-6xl md:text-9xl font-bold text-gray-800 mb-4">404</h1>
            <h2 className="text-3xl md:text-4xl font-semibold text-gray-700 mb-6">Not Found</h2>
            <p className="text-gray-600 text-base md:text-lg mb-8">
                Your visited page not found. You may go home page.
            </p>
            <a href="/"
                className="bg-red-500 hover:bg-red-600 text-white font-semibold py-3 px-6 md:px-8 rounded-lg transition duration-300">
                Back to home page
            </a>
        </div>
    </div>
</div>

        </>
    )
}