export function Category () {
    return (
        <>
           <div className="bg-gray-100 p-4 md:p-10">
    <h2 className="text-xl md:text-2xl font-semibold mb-6 text-center md:text-left">Category name</h2>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(8)].map((_, index) => (
            <a href="/product-details" key={index} className="bg-white p-4 rounded-lg shadow-md relative">
                {index % 4 === 0 && (
                    <span className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded">-35%</span>
                )}
                <img src="./src/assets/abcd.png" alt="Product" className="w-full h-40 object-cover mb-3"/>
                <button className="w-full bg-black text-white py-2 flex justify-center items-center gap-2">
                    🛒 Add To Cart
                </button>
                <h3 className="mt-2 text-lg font-semibold">Gucci duffle bag</h3>
                <p className="text-red-500">$960 <span className="text-gray-400 line-through">$1160</span></p>
            </a>
        ))}
    </div>
    <div className="mt-8 flex justify-center gap-2">
        <button className="px-4 py-2 bg-gray-300 rounded-md">Prev</button>
        <button className="px-4 py-2 bg-blue-500 text-white rounded-md">1</button>
        <button className="px-4 py-2 bg-gray-300 rounded-md">2</button>
        <button className="px-4 py-2 bg-gray-300 rounded-md">Next</button>
    </div>
</div>

        </>
    )
}