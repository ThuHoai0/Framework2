import { useQuery } from "@tanstack/react-query";
import { IProduct } from "../interface/product";
import { api } from "../config/axios";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import ClientHeader from "../components/client/header";
import { useState } from "react";

const CategoryProducts = () => {
    const { categoryName } = useParams();
    const [searchKeyword, setSearchKeyword] = useState<string>("");

    const { data: products, isLoading } = useQuery<IProduct[]>({
        queryKey: ["products", categoryName],
        queryFn: async () => {
            try {
                const { data } = await api.get("http://localhost:3000/products");
                return data.filter((product: IProduct) => product.category === categoryName);
            } catch (error) {
                console.log(error);
                return [];
            }
        }
    });

    const handleSearch = (keyword: string) => {
        setSearchKeyword(keyword);
    };

    const searchedProducts = products?.filter((product) =>
        product.name.toLowerCase().includes(searchKeyword.toLowerCase())
    );

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="text-xl">Đang tải dữ liệu...</div>
            </div>
        );
    }

    return (
        <>
            <div className="container mx-auto p-6">
                <h1 className="text-2xl font-bold mb-6">{categoryName}</h1>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {searchedProducts && searchedProducts.length > 0 ? (
                        searchedProducts.map((product) => (
                            <div key={product.id} className="group">
                                <div className="relative h-[300px] bg-[#F5F5F5] rounded-lg mb-4">
                                    <div className="absolute top-2 left-2">
                                        {product.discount && (
                                            <span className="bg-red-500 text-white text-sm px-3 py-1 rounded">
                                                -{product.discount}%
                                            </span>
                                        )}
                                    </div>
                                    <div>
                                        <img 
                                            src={product.images} 
                                            alt={product.name}
                                            className="w-full h-[250px] object-contain p-5"
                                        />
                                    </div>
                                    <div className="absolute top-2 right-2">
                                        <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                            <img src="/src/assets/icon-delete.png" alt="Delete" className="w-5 h-5" />
                                        </button>
                                    </div>
                                </div>

                                <div>
                                    <h3 className="font-medium text-lg mb-2">{product.name}</h3>
                                </div>

                                <div className="flex items-center gap-2 mb-2">
                                    <span className="text-red-500 font-semibold">${product.price}</span>
                                    {product.oldPrice && (
                                        <span className="text-gray-500 line-through">${product.oldPrice}</span>
                                    )}
                                </div>

                                <div className="flex items-center gap-1 mb-4">
                                    <div className="flex text-yellow-400">
                                        {[...Array(5)].map((_, i) => (
                                            <span key={i} className="text-yellow-400">★</span>
                                        ))}
                                    </div>
                                    <span className="text-gray-500">(65)</span>
                                </div>

                                <button className="w-full bg-black text-white py-2 rounded-md hover:bg-gray-800 transition-colors flex items-center justify-center gap-2">
                                    Add To Cart
                                </button>
                            </div>
                        ))
                    ) : (
                        <div className="col-span-full text-center text-gray-500">
                            Không tìm thấy sản phẩm nào
                        </div>
                    )}
                </div>
                
                {/* Pagination */}
                <div className="flex justify-center mt-8">
                    <nav className="flex items-center gap-2">
                        <button className="px-3 py-1 border rounded hover:bg-gray-100">1</button>
                        <button className="px-3 py-1 border rounded hover:bg-gray-100">2</button>
                        <button className="px-3 py-1 border rounded hover:bg-gray-100">3</button>
                        <span>...</span>
                        <button className="px-3 py-1 border rounded hover:bg-gray-100">6</button>
                    </nav>
                </div>
            </div>
        </>
    );
};

export default CategoryProducts; 