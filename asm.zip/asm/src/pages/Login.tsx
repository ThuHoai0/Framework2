import { useForm } from "react-hook-form";
import { IUser } from "../interface/user";
import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { message } from "antd";
import { api } from "../config/axios";


export function Login() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IUser>();
  const navigate = useNavigate();
  
  const mutation = useMutation({
    mutationFn: async (userdata: IUser) => {
      const { data } = await api.get(
        `/users?email=${userdata.email}&password=${userdata.password}`
      );
      if (data.length === 0) {
        throw new Error("Email hoặc mật khẩu không đúng");
      }
      return { accessToken: "fake-token", user: data[0] }; 
    },
    onSuccess: (response) => {
      if (response?.accessToken) {
        localStorage.setItem("token", response.accessToken);
        console.log(response.user);
    
        localStorage.setItem("user", JSON.stringify(response.user));
        message.success("Đăng nhập thành công");
        navigate("/");
      } else {
        message.error("Không nhận được token, vui lòng thử lại");
      }
    },
    onError: (error) => {
      message.error(`Đăng nhập thất bại: ${error.message || "Vui lòng thử lại"}`);
    },
  });

  const onSubmit = (userdata: IUser) => {
    mutation.mutate(userdata);
  };
  return (
    <div className="min-h-screen flex items-center justify-center bg-white mt-8">
      <div className="flex flex-col md:flex-row w-full h-screen">
        <div className="md:w-1/2 w-0 h-full">
          <img
            src="/src/assets/login.jpg"
            alt="Login Illustration"
            className="object-cover w-full h-full"
          />
        </div>

        <div className="md:w-1/2 w-full p-6 md:p-14 flex flex-col justify-center">
          <h1 className="text-2xl md:text-3xl font-bold text-[#1A1A1A] mb-2">
            Welcome back
          </h1>
          <p className="text-[#787878] mb-6 md:mb-10">
            Enter your credentials to access your account
          </p>

          <form
            onSubmit={handleSubmit(onSubmit)}
            className="flex flex-col gap-6 md:gap-8"
          >
            <div className="flex flex-col gap-1">
              <input
                type="text"
                placeholder="Email"
                className="border-b-2 border-[#CCCCCC] pb-3 focus:border-[#1A1A1A] outline-none placeholder-[#787878] text-lg"
                {...register("email", {
                  required: "Email không được để trống",
                  pattern: {
                    value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                    message: "Email sai định dạng",
                  },
                })}
              />
              {errors?.email && (
                <p className="text-red-500">{errors?.email?.message}</p>
              )}
            </div>

            <div className="flex flex-col gap-1">
              <input
                type="password"
                placeholder="Password"
                className="border-b-2 border-[#CCCCCC] pb-3 focus:border-[#1A1A1A] outline-none placeholder-[#787878] text-lg"
                {...register("password", {
                  required: "Mật khẩu không được để trống",
                  minLength: {
                    value: 6,
                    message: "Mật khẩu phải có ít nhất 6 ký tự",
                  },
                })}
              />
              {errors?.password && (
                <p className="text-red-500">{errors?.password?.message}</p>
              )}
            </div>

            <div className="flex items-center justify-between gap-4">
              <button
                type="submit"
                className="flex-1 bg-[#DB4444] text-white py-4 rounded-md font-medium hover:bg-[#C93535] transition-colors"
                disabled={mutation.isPending}
              >
                {mutation.isPending ? "Logging in..." : "Login"}
              </button>
              <a
                href="/register"
                className="text-[#DB4444] font-medium hover:underline whitespace-nowrap"
              >
                Don't have an account? Register
              </a>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
