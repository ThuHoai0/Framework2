import { Navigate, useLocation } from 'react-router-dom';
import { ReactNode } from 'react';

interface UserData {
  role: string;

  [key: string]: any;
}

interface PrivateRouteProps {
  children: ReactNode;
  requiredRole?: string; 
}

const PrivateRoute = ({ children, requiredRole = 'admin' }: PrivateRouteProps) => {
  const location = useLocation();
  
  const user: UserData | null = JSON.parse(localStorage.getItem('user') || 'null');
  const isAuthorized = user?.role === requiredRole;

  if (!isAuthorized) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

export default PrivateRoute;