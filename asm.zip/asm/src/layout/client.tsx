
import ClientHeader from '../components/client/header'
import ClientFooter from '../components/client/footer'
import { Outlet, useNavigate } from 'react-router-dom'

const ClientLayout = () => {
  const navigate = useNavigate();

  const handleSearch = (keyword: string) => {
    navigate(`/search/?keyword=${encodeURIComponent(keyword)}`);
  };

  return (
    <>
        <ClientHeader onSearch={handleSearch}/>
        <div className='max-w-7xl mx-auto'>
          <Outlet/>
          </div>
        <ClientFooter/>
    </>
  )
}

export default ClientLayout