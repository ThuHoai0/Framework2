import {useQuery} from "@tanstack/react-query";
import {IProduct} from "../../interface/product.ts";
import {api} from "../../config/axios.ts";
import {ICategory} from "../../interface/category.ts";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import { message } from "antd";
import { ICartItem } from "../../interface/cart.ts";

const Home = () => {
    const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
    const navigate = useNavigate();
    const { addToCart } = useCart();

    const {data, isLoading: isLoadingProduct} = useQuery<IProduct[]>({
        queryKey: ["products"],
        queryFn: async ()=>{
            try {
                const {data:products} = await api.get("http://localhost:3000/products")
                return products
            } catch (error) {
                console.log(error);
            }
        }
    })
    const { data: categories, isLoading: isLoadingCategory } = useQuery<ICategory[]>({
        queryKey: ["categories"],
        queryFn: async () => {
            try {
                const { data } = await api.get("http://localhost:3000/categories");
                return data;
            } catch (error) {
                console.log(error);
            }
        },
    });

    const handleAddToCart = (product: IProduct) => {
        const user = JSON.parse(localStorage.getItem("user") || "{}");
        if (!user || !user.id) {
            message.warning("Vui lòng đăng nhập để thêm sản phẩm vào giỏ hàng");
            navigate("/login");
            return;
        }

        const cartItem: ICartItem = {
            id: product.id,
            name: product.name,
            price: product.price,
            images: product.images,
            quantity: 1,
            categoryID: product.categoryID
        };
        addToCart(cartItem);
        message.success("Đã thêm sản phẩm vào giỏ hàng");
    };

    if (isLoadingProduct){
        return <>Đang tải dữ liệu</>
    }
    if (isLoadingCategory){
        return <>Đang tải dữ liệu</>
    }
    return (
        <>
            {/* 1 */}
            <div className="container mx-auto flex flex-col md:flex-row gap-6 mt-6">
                {/* Thanh công cụ */}
                <nav className="w-full md:w-1/4 bg-white shadow-lg p-4 rounded-lg">
                    <ul className="space-y-2 text-center md:text-left">
                       <li>Woman's Fashion</li>
                       <li>Men's Fashion</li>
                       <li>Electronic</li>
                       <li>Home & Lifestyle</li>
                       <li>Medicine</li>
                       <li>Sports & Outdoor</li>
                       <li>Baby's & Toys</li>
                       <li>Groceries & Pets</li>
                       <li>Health & Beauty</li>
                    </ul>
                </nav>

                {/* Banner chạy tự động */}
                <div className="w-full md:w-3/4 relative">
                    <div className="overflow-hidden rounded-lg shadow-lg">
                        <div className="flex transition-transform duration-500 ease-in-out" id="banner-slider">
                            <img src="/src/assets/Frame%20560.png" alt="Banner 1" className="w-full h-auto" />
                        </div>
                    </div>
                </div>
            </div>
            {/* 2 */}
            <div className="container mx-auto mt-10">
                {/* Tiêu đề */}
                <div className="flex items-center gap-3">
                    <span className="bg-red-500 h-6 w-2 rounded"></span>
                    <p className="text-red-500 font-semibold">Categories</p>
                </div>
                <div className="flex justify-between items-center mt-4">
                    <h1 className="text-2xl font-bold">Browse By Category</h1>
                    <div className="flex gap-3">
                        <button className="p-2 bg-gray-200 rounded-full text-lg">&#8592;</button>
                        <button className="p-2 bg-gray-200 rounded-full text-lg">&#8594;</button>
                    </div>
                </div>
                {/* Danh mục */}
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-6">
                    <div 
                        onClick={() => setSelectedCategory(null)}
                        className={`flex flex-col items-center p-4 border rounded-lg transition text-center 
                        ${!selectedCategory ? "bg-red-500 text-white" : "hover:bg-red-500 hover:text-white"}`}
                    >
                        <img src="/src/assets/Category-Gamepad.png" alt="Tất cả sản phẩm" className="w-12 h-12 mb-2" />
                        <span>Tất cả sản phẩm</span>
                    </div>
                    {categories && categories.length > 0 ? (
                        categories.map((category) => (
                            <div
                                key={category.id}
                                onClick={() => navigate(`/category/${category.name}`)}
                            className={`flex flex-col items-center p-4 border rounded-lg transition text-center 
                                ${selectedCategory === category.name ? "bg-red-500 text-white" : "hover:bg-red-500 hover:text-white"}`}
                            >
                                <img src="/src/assets/Category-Gamepad.png" alt={category.name} className="w-12 h-12 mb-2" />
                                <span>{category.name}</span>
                            </div>
                        ))
                    ) : (
                        <div className="col-span-full text-center text-gray-500">
                            Không có danh mục nào
                        </div>
                    )}
                </div>
            </div>
            <br />
            <hr />
            {/* 3 */}
            <div className="mt-10">
                {/* Tiêu đề */}
                <div className="flex items-center gap-3">
                    <span className="bg-red-500 h-6 w-2 rounded"></span>
                    <p className="text-red-500 font-semibold">This Month</p>
                </div>
                <div className="flex justify-between items-center mt-4">
                    <h1 className="text-2xl font-bold">Best Selling Products</h1>
                    <button className="mt-8 px-10 p-2 bg-red-500 text-white rounded">View All</button>
                </div>
                {/*lab5*/}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-6">
                    {/* Product Card 1 */}
                    <div className="group">
                        <div className="relative h-[300px] bg-[#F5F5F5] rounded-lg mb-4">
                            <div>
                                <img 
                                    src="/src/assets/ao.png" 
                                    alt="The north coat" 
                                    className="w-full h-[250px] object-contain p-5"
                                />
                            </div>
                            <div className="absolute top-2 right-2 flex flex-col gap-2">
                                <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                    <img src="/src/assets/Fill Heart.png" alt="Wishlist" className="w-5 h-5" />
                                </button>
                                <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                    <img src="/src/assets/Fill Eye.png" alt="Quick view" className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                        <div>
                            <h3 className="font-medium text-lg mb-2">The north coat</h3>
                        </div>
                        <div className="flex items-center gap-2 mb-2">
                            <span className="text-red-500 font-semibold">$260</span>
                            <span className="text-gray-500 line-through">$360</span>
                        </div>
                        <div className="flex items-center gap-1">
                            <div className="flex text-yellow-400">
                                {[...Array(5)].map((_, i) => (
                                    <span key={i} className="text-yellow-400">★</span>
                                ))}
                            </div>
                            <span className="text-gray-500">(65)</span>
                        </div>
                    </div>

                    {/* Product Card 2 */}
                    <div className="group">
                        <div className="relative h-[300px] bg-[#F5F5F5] rounded-lg mb-4">
                            <div>
                                <img 
                                    src="/src/assets/abcd.png" 
                                    alt="Gucci duffle bag" 
                                    className="w-full h-[250px] object-contain p-5"
                                />
                            </div>
                            <div className="absolute top-2 right-2 flex flex-col gap-2">
                                <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                    <img src="/src/assets/Fill Heart.png" alt="Wishlist" className="w-5 h-5" />
                                </button>
                                <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                    <img src="/src/assets/Fill Eye.png" alt="Quick view" className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                        <div>
                            <h3 className="font-medium text-lg mb-2">Gucci duffle bag</h3>
                        </div>
                        <div className="flex items-center gap-2 mb-2">
                            <span className="text-red-500 font-semibold">$960</span>
                            <span className="text-gray-500 line-through">$1160</span>
                        </div>
                        <div className="flex items-center gap-1">
                            <div className="flex text-yellow-400">
                                {[...Array(5)].map((_, i) => (
                                    <span key={i} className="text-yellow-400">★</span>
                                ))}
                            </div>
                            <span className="text-gray-500">(65)</span>
                        </div>
                    </div>

                    {/* Product Card 3 */}
                    <div className="group">
                        <div className="relative h-[300px] bg-[#F5F5F5] rounded-lg mb-4">
                            <div>
                                <img 
                                    src="/src/assets/loa.png" 
                                    alt="RGB liquid CPU Cooler" 
                                    className="w-full h-[250px] object-contain p-5"
                                />
                            </div>
                            <div className="absolute top-2 right-2 flex flex-col gap-2">
                                <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                    <img src="/src/assets/Fill Heart.png" alt="Wishlist" className="w-5 h-5" />
                                </button>
                                <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                    <img src="/src/assets/Fill Eye.png" alt="Quick view" className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                        <div>
                            <h3 className="font-medium text-lg mb-2">RGB liquid CPU Cooler</h3>
                        </div>
                        <div className="flex items-center gap-2 mb-2">
                            <span className="text-red-500 font-semibold">$160</span>
                            <span className="text-gray-500 line-through">$170</span>
                        </div>
                        <div className="flex items-center gap-1">
                            <div className="flex text-yellow-400">
                                {[...Array(5)].map((_, i) => (
                                    <span key={i} className="text-yellow-400">★</span>
                                ))}
                            </div>
                            <span className="text-gray-500">(65)</span>
                        </div>
                    </div>

                    {/* Product Card 4 */}
                    <div className="group">
                        <div className="relative h-[300px] bg-[#F5F5F5] rounded-lg mb-4">
                            <div>
                                <img 
                                    src="/src/assets/tusach.png" 
                                    alt="Small BookSelf" 
                                    className="w-full h-[250px] object-contain p-5"
                                />
                            </div>
                            <div className="absolute top-2 right-2 flex flex-col gap-2">
                                <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                    <img src="/src/assets/Fill Heart.png" alt="Wishlist" className="w-5 h-5" />
                                </button>
                                <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                    <img src="/src/assets/Fill Eye.png" alt="Quick view" className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                        <div>
                            <h3 className="font-medium text-lg mb-2">Small BookSelf</h3>
                                        </div>
                        <div className="flex items-center gap-2 mb-2">
                            <span className="text-red-500 font-semibold">$360</span>
                            <span className="text-gray-500 line-through">$400</span>
                                </div>
                        <div className="flex items-center gap-1">
                            <div className="flex text-yellow-400">
                                {[...Array(5)].map((_, i) => (
                                    <span key={i} className="text-yellow-400">★</span>
                                ))}
                            </div>
                            <span className="text-gray-500">(65)</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* 4 */}
            <br />
            <div className="w-full">
                <img src="/src/assets/banner2.png" alt="Promotional Banner" className="mt-10"/>
            </div>

            <br />
           

            {/* 5 */}
           <div className="container mx-auto mt-16">
                {/* Tiêu đề */}
                <div className="flex items-center gap-3">
                    <span className="bg-red-500 h-6 w-2 rounded"></span>
                    <p className="text-red-500 font-semibold">Our Products</p>
                </div>
                <div className="flex justify-between items-center mt-4">
                    <h1 className="text-2xl font-bold">Explore Our Products</h1>
                    <div className="hidden md:flex gap-3">
                        <button className="p-2 bg-gray-200 rounded-full">&#8592;</button>
                        <button className="p-2 bg-gray-200 rounded-full">&#8594;</button>
                    </div>
                </div>

                {/* Danh sách sản phẩm */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-6">
                    {data && data.length > 0 ? (
                        data.map((product) => (
                            <div key={product.id} className="group">
                                <div className="relative h-[300px] bg-[#F5F5F5] rounded-lg mb-4">
                                    <Link to={`/product-details/${product.id}`}>
                                        <img 
                                            src={product.images} 
                                            alt={product.name}
                                            className="w-full h-[250px] object-contain p-5"
                                        />
                                    </Link>
                                    {/* Action buttons - always visible */}
                                    <div className="absolute top-2 right-2 flex flex-col gap-2">
                                        <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                            <img src="/src/assets/Fill Heart.png" alt="Wishlist" className="w-5 h-5" />
                                        </button>
                                        <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100">
                                            <img src="/src/assets/Fill Eye.png" alt="Quick view" className="w-5 h-5" />
                                        </button>
                                    </div>
                                    {/* Add to Cart Button - appears on hover over image */}
                                    <div className="absolute bottom-2 left-2 right-2 opacity-0 group-hover:opacity-100 transition-all duration-300">
                                        <button 
                                            className="w-full bg-black text-white py-2 rounded-md hover:bg-gray-800 transition-colors"
                                            onClick={() => handleAddToCart(product)}
                                        >
                                            Add To Cart
                                        </button>
                                    </div>
                                </div>

                                <Link to={`/product-details/${product.id}`}>
                                    <h3 className="font-medium text-lg mb-2">{product.name}</h3>
                                </Link>

                                <div className="flex items-center gap-4">
                                    <span className="text-red-500 font-semibold">${product.price}</span>
                                    {/* Rating */}
                                    <div className="flex items-center gap-1">
                                        <div className="flex text-yellow-400">
                                            {[...Array(5)].map((_, i) => (
                                                <span key={i} className="text-yellow-400">★</span>
                                            ))}
                                        </div>
                                        <span className="text-gray-500">(65)</span>
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="col-span-full text-center text-gray-500">
                            Không tìm thấy sản phẩm nào
                        </div>
                    )}
                </div>

                {/* Nút View All */}
                <button className="mt-16 mb-16 px-12 py-4 bg-red-500 text-white rounded-md block mx-auto hover:bg-red-600 transition-colors">
                    View All Products
                </button>
            </div>

            {/* 6 */}
           <div className="container mx-auto mt-16">
    {/* Tiêu đề */}
    <div className="flex items-center gap-3">
        <span className="bg-red-500 h-6 w-2 rounded"></span>
        <p className="text-red-500 font-semibold">Featured</p>
    </div>
    <div className="flex justify-between items-center mt-4">
        <h1 className="text-2xl font-bold">New Arrival</h1>
    </div>

                {/* Grid layout for New Arrival items */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                    {/* PlayStation 5 - Large card */}
                    <div className="relative bg-black rounded-lg overflow-hidden">
                        <img 
                            src="/src/assets/ps5.png" 
                            alt="PlayStation 5" 
                            className="w-full h-[600px] object-cover"
                        />
                        <div className="absolute bottom-8 left-8">
                            <h3 className="text-2xl font-bold text-white mb-2">PlayStation 5</h3>
                            <p className="text-gray-300 mb-4">Black and White version of the PS5 coming out on sale.</p>
                            <button className="text-white underline hover:text-gray-300">Shop Now</button>
                        </div>
                    </div>

                    {/* Right column grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Women's Collections */}
                        <div className="col-span-2 relative bg-black rounded-lg overflow-hidden">
                            <img 
                                src="/src/assets/women-collection.png" 
                                alt="Women's Collections" 
                                className="w-full h-[284px] object-cover"
                            />
                            <div className="absolute bottom-8 left-8">
                                <h3 className="text-2xl font-bold text-white mb-2">Women's Collections</h3>
                                <p className="text-gray-300 mb-4">Featured woman collections that give you another vibe.</p>
                                <button className="text-white underline hover:text-gray-300">Shop Now</button>
                            </div>
        </div>

                        {/* Speakers */}
                        <div className="relative bg-black rounded-lg overflow-hidden">
                            <img 
                                src="/src/assets/speakers.png" 
                                alt="Speakers" 
                                className="w-full h-[284px] object-cover"
                            />
                            <div className="absolute bottom-8 left-8">
                                <h3 className="text-2xl font-bold text-white mb-2">Speakers</h3>
                                <p className="text-gray-300 mb-4">Amazon wireless speakers</p>
                                <button className="text-white underline hover:text-gray-300">Shop Now</button>
            </div>
            </div>

                        {/* Perfume */}
                        <div className="relative bg-black rounded-lg overflow-hidden">
                            <img 
                                src="/src/assets/perfume.png" 
                                alt="Perfume" 
                                className="w-full h-[284px] object-cover"
                            />
                            <div className="absolute bottom-8 left-8">
                                <h3 className="text-2xl font-bold text-white mb-2">Perfume</h3>
                                <p className="text-gray-300 mb-4">GUCCI INTENSE OUD EDP</p>
                                <button className="text-white underline hover:text-gray-300">Shop Now</button>
            </div>
        </div>
    </div>
                </div>

</div>

            {/* 7 */}
            <div className="container mx-auto py-10 mt-16 mb-16">
    <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-center">
        {/* Free Delivery */}
        <div className="flex flex-col items-center">
            <div className="relative">
                <div className="h-16 w-16 bg-gray-300 rounded-full flex items-center justify-center shadow-lg">
                    <div className="h-12 w-12 bg-black rounded-full flex items-center justify-center hover:scale-110 transition-transform duration-300">
                                    <img src="/src/assets/1.png"
                            alt="Truck Icon" className="w-6 h-6 invert" />
                    </div>
                </div>
            </div>
            <h2 className="mt-4 text-lg font-bold text-gray-800">FREE AND FAST DELIVERY</h2>
            <p className="text-gray-500">Free delivery for all orders over $140</p>
        </div>

        {/* Customer Service */}
        <div className="flex flex-col items-center">
            <div className="relative">
                <div className="h-16 w-16 bg-gray-300 rounded-full flex items-center justify-center shadow-lg">
                    <div className="h-12 w-12 bg-black rounded-full flex items-center justify-center hover:scale-110 transition-transform duration-300">
                        <img src="https://cdn-icons-png.flaticon.com/128/724/724715.png"
                            alt="Headphones Icon" className="w-6 h-6 invert" />
                    </div>
                </div>
            </div>
            <h2 className="mt-4 text-lg font-bold text-gray-800">24/7 CUSTOMER SERVICE</h2>
            <p className="text-gray-500">Friendly 24/7 customer support</p>
        </div>

        {/* Money Back Guarantee */}
        <div className="flex flex-col items-center">
            <div className="relative">
                <div className="h-16 w-16 bg-gray-300 rounded-full flex items-center justify-center shadow-lg">
                    <div className="h-12 w-12 bg-black rounded-full flex items-center justify-center hover:scale-110 transition-transform duration-300">
                        <img src="https://cdn-icons-png.flaticon.com/128/1828/1828640.png"
                            alt="Shield Check Icon" className="w-6 h-6 invert" />
                    </div>
                </div>
            </div>
            <h2 className="mt-4 text-lg font-bold text-gray-800">MONEY BACK GUARANTEE</h2>
            <p className="text-gray-500">We return money within 30 days</p>
        </div>
    </div>
</div>
        </>
    )
}

export default Home