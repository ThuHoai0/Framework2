// import React from 'react'

const ClientFooter = () => {
  return (
      <>
      <footer className="bg-black text-white py-10 mt-10">
    <div className="max-w-6xl mx-auto px-6 grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
        {/* Exclusive */}
        <div>
            <h3 className="text-xl font-semibold">Exclusive</h3>
            <p className="mt-2">Subscribe</p>
            <p className="text-gray-400 text-sm">Get 10% off your first order</p>
            <div className="mt-3 flex items-center border border-gray-600 rounded-lg overflow-hidden">
                <input type="email" placeholder="Enter your email"
                    className="bg-transparent text-white p-2 w-full focus:outline-none"/>
                <button className="bg-white text-black px-3 py-2 hover:bg-gray-300">→</button>
            </div>
        </div>

        {/* Support */}
        <div>
            <h3 className="text-xl font-semibold">Support</h3>
            <ul className="mt-3 space-y-1 text-gray-400 text-sm">
                <li className="hover:text-white">111 Bijoy sarani, Dhaka, DH 1515, Bangladesh.</li>
                <li className="hover:text-white">exclusive@gmail.com</li>
                <li className="hover:text-white">+88015-88888-9999</li>
            </ul>
        </div>

        {/* Account */}
        <div>
            <h3 className="text-xl font-semibold">Account</h3>
            <ul className="mt-3 space-y-1 text-gray-400 text-sm">
                <li className="hover:text-white">My Account</li>
                <li className="hover:text-white">Login / Register</li>
                <li className="hover:text-white">Cart</li>
                <li className="hover:text-white">Wishlist</li>
                <li className="hover:text-white">Shop</li>
            </ul>
        </div>

        {/* Quick Link */}
        <div>
            <h3 className="text-xl font-semibold">Quick Link</h3>
            <ul className="mt-3 space-y-1 text-gray-400 text-sm">
                <li className="hover:text-white">Privacy Policy</li>
                <li className="hover:text-white">Terms Of Use</li>
                <li className="hover:text-white">FAQ</li>
                <li className="hover:text-white">Contact</li>
            </ul>
        </div>

        {/* Download App */}
        <div>
            <h3 className="text-xl font-semibold">Download App</h3>
            <p className="mt-2 text-gray-400 text-sm">Save $3 with App New User Only</p>
            <div className="mt-3 flex space-x-2">
                <img src="/src/assets/QR.jpg" alt="QR Code" className="w-16 h-16"/>
                <div>
                    <img src="/src/assets/google-play.png" alt="Google Play" className="h-10"/>
                    <img src="/src/assets/app-store.png" alt="App Store" className="h-10 mt-2"/>
                </div>
            </div>

            {/* Social Icons */}
            <div className="flex space-x-4 mt-4 text-gray-400">
                <a href="#" className="hover:text-white">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3l-10-9-10 9h3v8z"></path></svg>
                </a>
                <a href="#" className="hover:text-white">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M22 5.3c-.8.4-1.7.6-2.6.8 1-.6 1.7-1.6 2.1-2.8-.9.5-1.9.9-3 .9-1.8 0-3.3-1.6-3.3-3.3 0-.3 0-.7.1-1-3 .2-5.6 1.5-7.3 3.7-1 .1-1.9.5-2.6 1-1.7 2.2-.7 5 .3 6.5-1.5-.2-2.9-.5-4.1-1.3v.1c0 2.6 1.4 4.9 3.3 5.8-.5.1-1 .2-1.6.2-.4 0-.7 0-1-.1.7 2.1 2.6 3.7 4.9 3.7-1.8 1.4-4.1 2.3-6.6 2.3-.4 0-.8 0-1.2-.1 2.3 1.5 5.1 2.3 8 2.3 9.6 0 14.9-8 14.9-14.9v-.7c1-.7 1.8-1.5 2.5-2.4z"></path></svg>
                </a>
                <a href="#" className="hover:text-white">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M20 0h-16c-2.2 0-4 1.8-4 4v16c0 2.2 1.8 4 4 4h16c2.2 0 4-1.8 4-4v-16c0-2.2-1.8-4-4-4zm-8 5c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm0 15c-3.9 0-7-3.1-7-7s3.1-7 7-7 7 3.1 7 7-3.1 7-7 7zm0-3c-2.2 0-4-1.8-4-4s1.8-4 4-4 4 1.8 4 4-1.8 4-4 4z"></path></svg>
                </a>
            </div>
        </div>
    </div>

    {/* Copyright */}
    <hr className="border-gray-600 my-6"/>
    <p className="text-center text-gray-400 text-sm">© Copyright Rimel 2022. All rights reserved</p>
</footer>



      </>
  )
}

export default ClientFooter