import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useCart } from "../../context/CartContext";

interface HeaderProps {
  onSearch: (keyword: string) => void;
}

interface User {
  email: string;
  role?: string;
}

const ClientHeader = ({ onSearch }: HeaderProps) => {
  const [searchKeyword, setSearchKeyword] = useState("");
  const navigate = useNavigate();
  const { cart } = useCart();

  const token = localStorage.getItem("token");
  const user: User | null = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user")!)
    : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchKeyword);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    navigate("/");
    window.location.reload();
  };

  return (
    <>
      <header className="w-full">
        {/* Thanh khuyến mãi */}
        <div className="bg-black text-white text-center py-2 text-sm">
          <span>
            Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%!{" "}
          </span>
          <a href="#" className="font-semibold underline hover:text-gray-300">
            Shop Now
          </a>
        </div>

        {/* Header chính */}
        <div className="flex justify-between items-center py-4 px-6 md:px-10">
          {/* Logo */}
          <div className="text-2xl font-bold">Exclusive</div>

          {/* Menu điều hướng (Ẩn trên mobile) */}
          <nav className="hidden md:flex">
            <ul className="flex space-x-6 text-lg">
              {["Home", "Contact", "About", token ? "Profile" : "Sign Up"].map(
                (item) => (
                  <li key={item} className="relative group">
                    <a
                      href={
                        item === "Sign Up"
                          ? "/login"
                          : item === "Home"
                          ? "/"
                          : item === "Profile"
                          ? "/profile"
                          : "#"
                      }
                      className="hover:text-gray-600"
                    >
                      {item}
                    </a>
                    <div className="absolute bottom-0 left-0 w-0 h-[2px] bg-black transition-all duration-300 group-hover:w-full"></div>
                  </li>
                )
              )}
            </ul>
          </nav>

          {/* Thanh tìm kiếm & icon */}
          <div className="flex items-center space-x-4">
            <form className="relative" onSubmit={handleSubmit}>
              <input
                type="text"
                placeholder="What are you looking for?"
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                className="w-[200px] md:w-[300px] px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-black"
              />
              <button
                type="submit"
                className="absolute right-3 top-2 text-gray-500 hover:text-black"
              >
                <img
                  src="/src/assets/Component 2.png"
                  alt="Search Icon"
                  className="w-5 h-5"
                />
              </button>
            </form>
            {/* Icon yêu thích & giỏ hàng */}
            <Link to="/wishlist" className="text-xl cursor-pointer hover:opacity-75">
              <img
                src="/src/assets/Wishlist.png"
                alt="Wishlist"
                className="w-6 h-6"
              />
            </Link>
            <Link to="/cart" className="relative text-xl cursor-pointer hover:opacity-75">
              <img
                src="/src/assets/Cart1.png"
                alt="Cart"
                className="w-6 h-6"
              />
              {cart.items.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cart.items.length}
                </span>
              )}
            </Link>
            {/* Hiển thị user hoặc email */}
            {token && user ? (
              <div className="relative group">
                <span
                  className="text-lg font-medium cursor-pointer"
                  tabIndex={0}
                >
                  {user.email}
                </span>
                <div className="absolute right-0 mt-2 w-48 bg-white border rounded-md shadow-lg hidden group-focus-within:block z-10">
                  <div className="py-2">
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Đăng xuất
                    </button>
                    {user.role === "admin" && (
                      <button
                        onClick={() => navigate("/dashboard")}
                        className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Admin
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="relative group">
                <span
                  className="text-xl cursor-pointer hover:opacity-75"
                  tabIndex={0}
                >
                  <img
                    src="/src/assets/user.png"
                    alt="User"
                    className="w-6 h-6"
                  />
                </span>
                <div className="absolute right-0 mt-2 w-48 bg-white border rounded-md shadow-lg hidden group-focus-within:block z-10">
                  <div className="py-2">
                    <button
                      onClick={() => navigate("/login")}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Đăng nhập
                    </button>
                    <button
                      onClick={() => navigate("/register")}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Đăng ký
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <hr />
    </>
  );
};

export default ClientHeader;
