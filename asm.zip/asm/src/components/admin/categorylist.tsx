import { useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import React from "react";
import { ICategory } from "../../interface/category"; // Import interface danh mục
import { Link } from "react-router-dom";
import { Button, message, Popconfirm, Table } from "antd";
import { DeleteFilled, EditFilled, WarningFilled } from '@ant-design/icons';
import { api } from "../../config/axios";

const CategoryList = () => {
    const { data: categories, isLoading } = useQuery<ICategory[]>({
        queryKey: ["categories"],
        queryFn: async () => {
            const { data } = await api.get("http://localhost:3000/categories");
            return data;
        },
    });

    const queryClient = useQueryClient();

    const mutation = useMutation({
        mutationFn: async (id: number) => {
            await api.delete(`http://localhost:3000/categories/${id}`);
        },
        onSuccess: () => {
            message.success("Xóa danh mục thành công");
            queryClient.invalidateQueries({ queryKey: ["categories"] });
        },
    });

    const DelCategory = (id: number) => {
        mutation.mutate(id);
    };

    const columns = [
        {
            title: "STT",
            key: "stt",
            render: (_, __, index) => index + 1,
        },
        {
            title: "Tên danh mục",
            dataIndex: "name",
            key: "name",
        },
        {
            title: "Action",
            dataIndex: "id",
            key: "action",
            render: (id: number) => (
                <>
                    <Link to={`/dashboard/category-edit/${id}`}>
                        <Button className="mr-2" type="primary">
                            <EditFilled /> Sửa
                        </Button>
                    </Link>
                    <Popconfirm
                        title="Thông báo"
                        icon={<WarningFilled />}
                        description="Bạn thực sự muốn xóa danh mục này?"
                        onConfirm={() => DelCategory(id)}
                        okText="Đồng ý xóa"
                        cancelText="Hủy"
                    >
                        <Button danger>
                            <DeleteFilled /> Xóa
                        </Button>
                    </Popconfirm>
                </>
            ),
        },
    ];

    if (isLoading) {
        return <>Đang tải dữ liệu...</>;
    }

    return (
        <div>
            <h1 className="text-[2rem] text-center mb-5">Danh sách danh mục</h1>
            {categories && <Table dataSource={categories} columns={columns} rowKey={(data) => data.id} />}
        </div>
    );
};

export default CategoryList;
