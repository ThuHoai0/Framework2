import { useQueryClient, useMutation } from "@tanstack/react-query";
import React from "react";
import { useForm } from "react-hook-form";
import { ICategory } from "../../interface/category"; // Import interface danh mục
import { useNavigate } from "react-router-dom";
import { api } from "../../config/axios";

const CategoryAdd = () => {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm<ICategory>();

    const queryClient = useQueryClient();
    const navigate = useNavigate();

    const mutation = useMutation({
        mutationFn: async (category: ICategory) => {
            const { data } = await api.post("http://localhost:3000/categories", category);
            return data;
        },
        onSuccess: () => {
            alert("Thêm danh mục thành công");
            queryClient.invalidateQueries({ queryKey: ["categories"] });
            navigate("/dashboard/category-list");
        },
    });

    const onSubmit = (category: ICategory) => {
        mutation.mutate(category);
    };

    return (
        <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
            <h1 className="text-2xl font-semibold text-center mb-4">Thêm mới danh mục</h1>
            <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
                <div>
                    <label className="block text-gray-700 font-medium">Tên danh mục</label>
                    <input
                        type="text"
                        {...register("name", { required: "Tên danh mục không được để trống" })}
                        className="w-full border border-gray-300 px-3 py-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                    {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>}
                </div>

                <button className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition">
                    Thêm mới
                </button>
            </form>
        </div>
    );
};

export default CategoryAdd;
