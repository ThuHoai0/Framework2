import { useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import React from "react";
import { useForm } from "react-hook-form";
import { IProduct } from "../../interface/product";
import { ICategory } from "../../interface/category";
import { useNavigate } from "react-router-dom";
import { api } from "../../config/axios";
import { Button, Form, Input, Select, message, Upload } from "antd";
import { PlusOutlined } from '@ant-design/icons';

const ProductAdd = () => {
    const [form] = Form.useForm();
    const navigate = useNavigate();
    const queryClient = useQueryClient();

    const { data: categories, isLoading: isLoadingCategories } = useQuery<ICategory[]>({
        queryKey: ["categories"],
        queryFn: async () => {
            const { data } = await api.get("http://localhost:3000/categories");
            return data;
        },
    });

    const mutation = useMutation({
        mutationFn: async (product: IProduct) => {
            const { data } = await api.post("http://localhost:3000/products", product);
            return data;
        },
        onSuccess: () => {
            message.success("Thêm sản phẩm thành công");
            queryClient.invalidateQueries({ queryKey: ["products"] });
            navigate("/dashboard/product-list");
        },
        onError: () => {
            message.error("Thêm sản phẩm thất bại");
        }
    });

    const onFinish = (values: IProduct) => {
        mutation.mutate(values);
    };

    return (
        <div className="p-6">
            <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
                <h1 className="text-2xl font-bold text-center mb-6">Thêm sản phẩm mới</h1>
                
                <Form
                    form={form}
                    layout="vertical"
                    onFinish={onFinish}
                    className="space-y-4"
                >
                    <Form.Item
                        label="Tên sản phẩm"
                        name="name"
                        rules={[
                            { required: true, message: "Vui lòng nhập tên sản phẩm" },
                            { min: 3, message: "Tên sản phẩm phải có ít nhất 3 ký tự" }
                        ]}
                    >
                        <Input placeholder="Nhập tên sản phẩm" />
                    </Form.Item>

                    <Form.Item
                        label="Ảnh sản phẩm"
                        name="images"
                        rules={[{ required: true, message: "Vui lòng nhập URL ảnh" }]}
                    >
                        <Input placeholder="Nhập URL ảnh sản phẩm" />
                    </Form.Item>

                    <Form.Item
                        label="Giá sản phẩm"
                        name="price"
                        rules={[
                            { required: true, message: "Vui lòng nhập giá sản phẩm" },
                            { 
                                validator: (_, value) => {
                                    const numValue = Number(value);
                                    if (isNaN(numValue)) {
                                        return Promise.reject("Giá phải là số");
                                    }
                                    if (numValue < 1000) {
                                        return Promise.reject("Giá phải lớn hơn 1000");
                                    }
                                    return Promise.resolve();
                                }
                            }
                        ]}
                    >
                        <Input type="number" placeholder="Nhập giá sản phẩm" />
                    </Form.Item>

                    <Form.Item
                        label="Danh mục"
                        name="category"
                        rules={[{ required: true, message: "Vui lòng chọn danh mục" }]}
                    >
                        <Select
                            placeholder="Chọn danh mục"
                            loading={isLoadingCategories}
                        >
                            {categories?.map((category) => (
                                <Select.Option key={category.id} value={category.name}>
                                    {category.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item>
                        <Button 
                            type="primary" 
                            htmlType="submit" 
                            className="w-full"
                            icon={<PlusOutlined />}
                        >
                            Thêm sản phẩm
                        </Button>
                    </Form.Item>
                </Form>
            </div>
        </div>
    );
};

export default ProductAdd;
