import { useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { IProduct } from "../../interface/product";
import { ICategory } from "../../interface/category";
import { api } from "../../config/axios";
import { Button, Form, Input, Select, message, Spin } from "antd";
import { SaveOutlined } from '@ant-design/icons';

const ProductEdit = () => {
    const [form] = Form.useForm();
    const params = useParams();
    const navigate = useNavigate();
    const queryClient = useQueryClient();

    const { data: product, isLoading: isLoadingProduct } = useQuery<IProduct>({
        queryKey: ["product", params.id],
        queryFn: async () => {
            const { data } = await api.get(`http://localhost:3000/products/${params.id}`);
            return data;
        },
        onSuccess: (product) => {
            form.setFieldsValue(product);
        },
    });

    const { data: categories, isLoading: isLoadingCategories } = useQuery<ICategory[]>({
        queryKey: ["categories"],
        queryFn: async () => {
            const { data } = await api.get("http://localhost:3000/categories");
            return data;
        },
    });

    const mutation = useMutation({
        mutationFn: async (updatedProduct: IProduct) => {
            const { data } = await api.put(`http://localhost:3000/products/${params.id}`, updatedProduct);
            return data;
        },
        onSuccess: () => {
            message.success("Cập nhật sản phẩm thành công");
            queryClient.invalidateQueries({ queryKey: ["products"] });
            navigate("/dashboard/product-list");
        },
        onError: () => {
            message.error("Cập nhật sản phẩm thất bại");
        }
    });

    const onFinish = (values: IProduct) => {
        mutation.mutate(values);
    };

    if (isLoadingProduct) {
        return (
            <div className="flex justify-center items-center h-64">
                <Spin size="large" />
            </div>
        );
    }

    return (
        <div className="p-6">
            <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
                <h1 className="text-2xl font-bold text-center mb-6">Cập nhật sản phẩm</h1>
                
                <Form
                    form={form}
                    layout="vertical"
                    onFinish={onFinish}
                    className="space-y-4"
                >
                    <Form.Item
                        label="Tên sản phẩm"
                        name="name"
                        rules={[
                            { required: true, message: "Vui lòng nhập tên sản phẩm" },
                            { min: 3, message: "Tên sản phẩm phải có ít nhất 3 ký tự" }
                        ]}
                    >
                        <Input placeholder="Nhập tên sản phẩm" />
                    </Form.Item>

                    <Form.Item
                        label="Ảnh sản phẩm"
                        name="images"
                        rules={[{ required: true, message: "Vui lòng nhập URL ảnh" }]}
                    >
                        <Input placeholder="Nhập URL ảnh sản phẩm" />
                    </Form.Item>

                    <Form.Item
                        label="Giá sản phẩm"
                        name="price"
                        rules={[
                            { required: true, message: "Vui lòng nhập giá sản phẩm" },
                            { 
                                validator: (_, value) => {
                                    const numValue = Number(value);
                                    if (isNaN(numValue)) {
                                        return Promise.reject("Giá phải là số");
                                    }
                                    if (numValue < 1000) {
                                        return Promise.reject("Giá phải lớn hơn 1000");
                                    }
                                    return Promise.resolve();
                                }
                            }
                        ]}
                    >
                        <Input type="number" placeholder="Nhập giá sản phẩm" />
                    </Form.Item>

                    <Form.Item
                        label="Danh mục"
                        name="category"
                        rules={[{ required: true, message: "Vui lòng chọn danh mục" }]}
                    >
                        <Select
                            placeholder="Chọn danh mục"
                            loading={isLoadingCategories}
                        >
                            {categories?.map((category) => (
                                <Select.Option key={category.id} value={category.name}>
                                    {category.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item>
                        <Button 
                            type="primary" 
                            htmlType="submit" 
                            className="w-full"
                            icon={<SaveOutlined />}
                        >
                            Cập nhật sản phẩm
                        </Button>
                    </Form.Item>
                </Form>
            </div>
        </div>
    );
};

export default ProductEdit;
