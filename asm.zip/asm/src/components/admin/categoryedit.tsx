import { useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import React from "react";
import { useForm } from "react-hook-form";
import { ICategory } from "../../interface/category"; // Import interface danh mục
import { useNavigate, useParams } from "react-router-dom";
import { api } from "../../config/axios";

const CategoryEdit = () => {
    const { register, handleSubmit, reset } = useForm<ICategory>();
    const { id } = useParams(); // Lấy id từ URL
    const { data: category, isLoading } = useQuery<ICategory>({
        queryKey: ["category", id],
        queryFn: async () => {
            const { data } = await api.get(`http://localhost:3000/categories/${id}`);
            reset(data); // Đặt giá trị mặc định cho form
            return data;
        },
    });

    const queryClient = useQueryClient();
    const navigate = useNavigate();

    const mutation = useMutation({
        mutationFn: async (category: ICategory) => {
            const { data } = await api.put(`http://localhost:3000/categories/${id}`, category);
            return data;
        },
        onSuccess: () => {
            alert("Cập nhật danh mục thành công");
            queryClient.invalidateQueries({ queryKey: ["categories"] });
            navigate("/dashboard/category-list");
        },
    });

    const onSubmit = (category: ICategory) => {
        mutation.mutate(category);
    };

    if (isLoading) {
        return <>Đang tải...</>;
    }

    return (
        <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
            <h1 className="text-2xl font-semibold text-center mb-4">Chỉnh sửa danh mục</h1>
            <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
                <div>
                    <label className="block text-gray-700 font-medium">Tên danh mục</label>
                    <input
                        type="text"
                        {...register("name", { required: "Tên danh mục không được để trống" })}
                        className="w-full border border-gray-300 px-3 py-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                        defaultValue={category?.name}
                    />
                    {mutation.isError && <p className="text-red-500 text-sm mt-1">Cập nhật không thành công.</p>}
                </div>

                <button className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition">
                    Cập nhật
                </button>
            </form>
        </div>
    );
};

export default CategoryEdit;
