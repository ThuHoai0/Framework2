import {
    useMutation,
    useQuery,
    useQueryClient,
} from "@tanstack/react-query";
import React from "react";
import { IProduct } from "../../interface/product";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../../config/axios";
import { Button, message, Popconfirm, Table, Space, Input } from "antd";
import { DeleteFilled, EditFilled, PlusOutlined, SearchOutlined } from '@ant-design/icons';
import { useState } from "react";

const ProductList = () => {
    const [searchText, setSearchText] = useState("");
    const navigate = useNavigate();
    const queryClient = useQueryClient();

    const { data, isLoading } = useQuery<IProduct[]>({
        queryKey: ["products"],
        queryFn: async () => {
            try {
                const { data: products } = await api.get("http://localhost:3000/products");
                return products;
            } catch (error) {
                return [];
            }
        },
    });

    const mutation = useMutation({
        mutationFn: async (id: number) => {
            try {
                await api.delete(`http://localhost:3000/products/${id}`);
            } catch (error) {
                console.log(error);
            }
        },
        onSuccess: () => {
            message.success("Xóa sản phẩm thành công");
            queryClient.invalidateQueries({ queryKey: ["products"] });
        },
        onError: () => {
            message.error("Xóa sản phẩm thất bại");
        }
    });

    const DelProduct = (id: number) => {
        mutation.mutate(id);
    };

    const filteredData = data?.filter(product => 
        product.name.toLowerCase().includes(searchText.toLowerCase()) ||
        product.category.toLowerCase().includes(searchText.toLowerCase())
    );

    const columns = [
        {
            title: "STT",
            key: "stt",
            render: (_: any, __: any, index: number) => index + 1,
            width: 60,
        },
        {
            title: "Ảnh sản phẩm",
            dataIndex: "images",
            key: "images",
            render: (image: string) => (
                <img 
                    src={image} 
                    alt="Product" 
                    className="w-20 h-20 object-cover rounded"
                />
            ),
            width: 120,
        },
        {
            title: "Tên sản phẩm",
            dataIndex: "name",
            key: "name",
            sorter: (a: IProduct, b: IProduct) => a.name.localeCompare(b.name),
        },
        {
            title: "Giá sản phẩm",
            dataIndex: "price",
            key: "price",
            sorter: (a: IProduct, b: IProduct) => a.price - b.price,
            render: (price: number) => (
                <span className="text-red-500 font-semibold">
                    {price.toLocaleString('vi-VN')}đ
                </span>
            ),
        },
        {
            title: "Danh mục",
            dataIndex: "category",
            key: "category",
            filters: data?.map(product => ({
                text: product.category,
                value: product.category,
            })),
            onFilter: (value: string, record: IProduct) => record.category === value,
        },
        {
            title: "Thao tác",
            key: "action",
            render: (_: any, record: IProduct) => (
                <Space size="middle">
                    <Button 
                        type="primary" 
                        icon={<EditFilled />}
                        onClick={() => navigate(`/dashboard/product-edit/${record.id}`)}
                    >
                        Sửa
                    </Button>
                    <Popconfirm 
                        title="Xóa sản phẩm"
                        description="Bạn có chắc chắn muốn xóa sản phẩm này?"
                        onConfirm={() => DelProduct(record.id)}
                        okText="Đồng ý"
                        cancelText="Hủy"
                    >
                        <Button danger icon={<DeleteFilled />}>
                            Xóa
                        </Button>
                    </Popconfirm>
                </Space>
            ),
            width: 200,
        },
    ];

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Quản lý sản phẩm</h1>
                <Button 
                    type="primary" 
                    icon={<PlusOutlined />}
                    onClick={() => navigate("/dashboard/product-add")}
                >
                    Thêm sản phẩm
                </Button>
            </div>

            <div className="mb-4">
                <Input
                    placeholder="Tìm kiếm sản phẩm..."
                    prefix={<SearchOutlined />}
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    className="w-64"
                />
            </div>

            <Table 
                dataSource={filteredData} 
                columns={columns} 
                rowKey="id"
                loading={isLoading}
                pagination={{
                    pageSize: 5,
                    showSizeChanger: true,
                    showQuickJumper: true,
                }}
            />
        </div>
    );
};

export default ProductList;
