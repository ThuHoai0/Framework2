import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Statistic, Table, DatePicker, Button, Select, Badge, Spin } from 'antd';
import { useQuery } from '@tanstack/react-query';
import { api } from '../../config/axios';
import { 
    ShoppingCartOutlined, 
    DollarOutlined, 
    UserOutlined, 
    RiseOutlined,
    BarChartOutlined
} from '@ant-design/icons';
import type { DatePickerProps } from 'antd';
import dayjs from 'dayjs';

// Interface for Order data
interface IOrder {
    id: number;
    userId: number;
    userEmail: string;
    items: {
        id: number;
        name: string;
        price: string;
        images: string;
        quantity: number;
    }[];
    total: number;
    orderDate: string;
    status: string;
}

// Interface for Product data
interface IProduct {
    id: number;
    name: string;
    images: string;
    price: string;
    categoryID?: number;
    category?: string;
}

// Interface for Category data
interface ICategory {
    id: number;
    name: string;
}

// Interface for User data
interface IUser {
    id: number;
    email: string;
    role: string;
}

const Thongke = () => {
    const [dateRange, setDateRange] = useState<[dayjs.Dayjs, dayjs.Dayjs] | null>(null);
    const [statusFilter, setStatusFilter] = useState<string | null>(null);
    const [filteredOrders, setFilteredOrders] = useState<IOrder[]>([]);
    
    // Fetch orders
    const { data: orders, isLoading: ordersLoading } = useQuery<IOrder[]>({
        queryKey: ['orders'],
        queryFn: async () => {
            const { data } = await api.get('http://localhost:3000/orders');
            return data;
        }
    });

    // Fetch products
    const { data: products, isLoading: productsLoading } = useQuery<IProduct[]>({
        queryKey: ['products'],
        queryFn: async () => {
            const { data } = await api.get('http://localhost:3000/products');
            return data;
        }
    });

    // Fetch categories
    const { data: categories, isLoading: categoriesLoading } = useQuery<ICategory[]>({
        queryKey: ['categories'],
        queryFn: async () => {
            const { data } = await api.get('http://localhost:3000/categories');
            return data;
        }
    });

    // Fetch users
    const { data: users, isLoading: usersLoading } = useQuery<IUser[]>({
        queryKey: ['users'],
        queryFn: async () => {
            const { data } = await api.get('http://localhost:3000/users');
            return data;
        }
    });

    useEffect(() => {
        if (orders) {
            let filtered = [...orders];
            
            // Apply date range filter
            if (dateRange && dateRange[0] && dateRange[1]) {
                const startDate = dateRange[0].startOf('day');
                const endDate = dateRange[1].endOf('day');
                
                filtered = filtered.filter(order => {
                    const orderDate = dayjs(order.orderDate);
                    return orderDate.isAfter(startDate) && orderDate.isBefore(endDate);
                });
            }
            
            // Apply status filter
            if (statusFilter) {
                filtered = filtered.filter(order => order.status === statusFilter);
            }
            
            setFilteredOrders(filtered);
        }
    }, [orders, dateRange, statusFilter]);

    // Calculate statistics
    const totalRevenue = filteredOrders.reduce((sum, order) => sum + order.total, 0);
    const totalOrders = filteredOrders.length;
    const totalCustomers = users?.filter(user => user.role === 'user').length || 0;
    
    // Calculate best-selling products
    const getTopSellingProducts = () => {
        if (!filteredOrders.length) return [];
        
        const productMap = new Map();
        
        filteredOrders.forEach(order => {
            order.items.forEach(item => {
                const currentCount = productMap.get(item.id)?.quantity || 0;
                productMap.set(item.id, {
                    id: item.id,
                    name: item.name,
                    quantity: currentCount + item.quantity,
                    totalRevenue: (currentCount + item.quantity) * Number(item.price)
                });
            });
        });
        
        return Array.from(productMap.values())
            .sort((a, b) => b.quantity - a.quantity)
            .slice(0, 5);
    };

    // Calculate revenue by category
    const getRevenueByCategory = () => {
        if (!filteredOrders.length || !categories) return [];
        
        const categoryMap = new Map();
        
        filteredOrders.forEach(order => {
            order.items.forEach(item => {
                const product = products?.find(p => p.id === item.id);
                if (product && product.categoryID) {
                    const category = categories.find(c => c.id === product.categoryID);
                    if (category) {
                        const categoryName = category.name;
                        const currentRevenue = categoryMap.get(categoryName) || 0;
                        categoryMap.set(categoryName, currentRevenue + (Number(item.price) * item.quantity));
                    }
                }
            });
        });
        
        return Array.from(categoryMap.entries()).map(([category, revenue]) => ({
            category,
            revenue
        }));
    };

    // Date range picker handlers
    const handleRangeChange: DatePickerProps['onChange'] = (dates, dateStrings) => {
        if (dates) {
            setDateRange([dayjs(dateStrings[0]), dayjs(dateStrings[1])]);
        } else {
            setDateRange(null);
        }
    };
    
    // Reset filters
    const resetFilters = () => {
        setDateRange(null);
        setStatusFilter(null);
    };

    // Order table columns
    const orderColumns = [
        {
            title: 'ID',
            dataIndex: 'id',
            key: 'id',
        },
        {
            title: 'Khách hàng',
            dataIndex: 'userEmail',
            key: 'userEmail',
        },
        {
            title: 'Tổng tiền',
            dataIndex: 'total',
            key: 'total',
            render: (total: number) => `${total.toLocaleString('vi-VN')} đ`,
            sorter: (a: IOrder, b: IOrder) => a.total - b.total,
        },
        {
            title: 'Ngày đặt',
            dataIndex: 'orderDate',
            key: 'orderDate',
            render: (date: string) => dayjs(date).format('DD/MM/YYYY HH:mm'),
            sorter: (a: IOrder, b: IOrder) => dayjs(a.orderDate).unix() - dayjs(b.orderDate).unix(),
        },
        {
            title: 'Trạng thái',
            dataIndex: 'status',
            key: 'status',
            render: (status: string) => {
                let color = 'blue';
                if (status === 'completed') color = 'green';
                if (status === 'canceled') color = 'red';
                return <Badge color={color} text={status} />;
            },
        },
    ];

    // Best selling products columns
    const productColumns = [
        {
            title: 'Sản phẩm',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: 'Số lượng bán',
            dataIndex: 'quantity',
            key: 'quantity',
            sorter: (a: any, b: any) => a.quantity - b.quantity,
        },
        {
            title: 'Doanh thu',
            dataIndex: 'totalRevenue',
            key: 'totalRevenue',
            render: (revenue: number) => `${revenue.toLocaleString('vi-VN')} đ`,
            sorter: (a: any, b: any) => a.totalRevenue - b.totalRevenue,
        }
    ];

    // Category revenue columns
    const categoryColumns = [
        {
            title: 'Danh mục',
            dataIndex: 'category',
            key: 'category',
        },
        {
            title: 'Doanh thu',
            dataIndex: 'revenue',
            key: 'revenue',
            render: (revenue: number) => `${revenue.toLocaleString('vi-VN')} đ`,
            sorter: (a: any, b: any) => a.revenue - b.revenue,
        }
    ];

    const isLoading = ordersLoading || productsLoading || categoriesLoading || usersLoading;

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-[calc(100vh-64px)]">
                <Spin size="large" tip="Đang tải dữ liệu..." />
            </div>
        );
    }

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-6">Thống kê bán hàng</h1>
            
            {/* Filters */}
            <div className="mb-6 bg-white p-4 rounded-lg shadow-sm">
                <div className="flex flex-wrap gap-4 items-center">
                    <div>
                        <span className="mr-2">Khoảng thời gian:</span>
                        <DatePicker.RangePicker 
                            onChange={handleRangeChange}
                            value={dateRange as any}
                        />
                    </div>
                    <div>
                        <span className="mr-2">Trạng thái:</span>
                        <Select
                            style={{ width: 120 }}
                            placeholder="Tất cả"
                            value={statusFilter}
                            onChange={(value) => setStatusFilter(value)}
                            allowClear
                            options={[
                                { value: 'pending', label: 'Đang xử lý' },
                                { value: 'completed', label: 'Hoàn thành' },
                                { value: 'canceled', label: 'Đã hủy' },
                            ]}
                        />
                    </div>
                    <Button type="default" onClick={resetFilters}>Đặt lại</Button>
                </div>
            </div>
            
            {/* Stats Cards */}
            <Row gutter={16} className="mb-6">
                <Col xs={24} sm={12} md={6}>
                    <Card>
                        <Statistic
                            title="Tổng doanh thu"
                            value={totalRevenue}
                            prefix={<DollarOutlined />}
                            suffix="đ"
                            formatter={(value) => `${value.toLocaleString('vi-VN')}`}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} md={6}>
                    <Card>
                        <Statistic
                            title="Tổng đơn hàng"
                            value={totalOrders}
                            prefix={<ShoppingCartOutlined />}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} md={6}>
                    <Card>
                        <Statistic
                            title="Doanh thu trung bình/đơn"
                            value={totalOrders ? totalRevenue / totalOrders : 0}
                            prefix={<RiseOutlined />}
                            suffix="đ"
                            formatter={(value) => `${value.toLocaleString('vi-VN')}`}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} md={6}>
                    <Card>
                        <Statistic
                            title="Tổng khách hàng"
                            value={totalCustomers}
                            prefix={<UserOutlined />}
                        />
                    </Card>
                </Col>
            </Row>
            
            {/* Order List */}
            <Card 
                title={<div className="flex items-center"><ShoppingCartOutlined className="mr-2" /> Danh sách đơn hàng</div>} 
                className="mb-6"
            >
                <Table 
                    dataSource={filteredOrders} 
                    columns={orderColumns} 
                    rowKey="id"
                    pagination={{ pageSize: 5 }}
                />
            </Card>
            
            {/* Top Selling Products */}
            <Row gutter={16} className="mb-6">
                <Col xs={24} md={12}>
                    <Card 
                        title={<div className="flex items-center"><BarChartOutlined className="mr-2" /> Sản phẩm bán chạy</div>}
                    >
                        <Table 
                            dataSource={getTopSellingProducts()} 
                            columns={productColumns} 
                            rowKey="id"
                            pagination={false}
                        />
                    </Card>
                </Col>
                <Col xs={24} md={12}>
                    <Card 
                        title={<div className="flex items-center"><DollarOutlined className="mr-2" /> Doanh thu theo danh mục</div>}
                    >
                        <Table 
                            dataSource={getRevenueByCategory()} 
                            columns={categoryColumns} 
                            rowKey="category"
                            pagination={false}
                        />
                    </Card>
                </Col>
            </Row>
        </div>
    );
};

export default Thongke;
