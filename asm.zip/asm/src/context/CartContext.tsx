import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { ICartItem } from "../interface/cart.ts";

interface CartContextType {
    cart: {
        items: ICartItem[];
        total: number;
    };
    addToCart: (item: ICartItem) => void;
    removeFromCart: (itemId: number) => void;
    updateQuantity: (itemId: number, quantity: number) => void;
    clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider = ({ children }: { children: ReactNode }) => {
    const [cart, setCart] = useState<{ items: ICartItem[]; total: number }>({
        items: [],
        total: 0,
    });

    // Load cart data when user changes
    useEffect(() => {
        const loadCart = () => {
            const user = JSON.parse(localStorage.getItem("user") || "{}");
            if (user && user.id) {
                const savedCart = localStorage.getItem(`cart_${user.id}`);
                if (savedCart) {
                    setCart(JSON.parse(savedCart));
                } else {
                    setCart({ items: [], total: 0 });
                }
            } else {
                setCart({ items: [], total: 0 });
            }
        };

        // Load cart initially
        loadCart();

        // Add event listener for storage changes
        window.addEventListener('storage', loadCart);

        // Cleanup
        return () => {
            window.removeEventListener('storage', loadCart);
        };
    }, []);

    // Save cart data when it changes
    useEffect(() => {
        const user = JSON.parse(localStorage.getItem("user") || "{}");
        if (user && user.id) {
            localStorage.setItem(`cart_${user.id}`, JSON.stringify(cart));
        }
    }, [cart]);

    const addToCart = (item: ICartItem) => {
        setCart((prevCart) => {
            const existingItem = prevCart.items.find((i) => i.id === item.id);
            if (existingItem) {
                const updatedItems = prevCart.items.map((i) =>
                    i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
                );
                const total = updatedItems.reduce(
                    (sum, item) => sum + Number(item.price) * item.quantity,
                    0
                );
                return { items: updatedItems, total };
            } else {
                const newItems = [...prevCart.items, { ...item, quantity: 1 }];
                const total = newItems.reduce(
                    (sum, item) => sum + Number(item.price) * item.quantity,
                    0
                );
                return { items: newItems, total };
            }
        });
    };

    const removeFromCart = (itemId: number) => {
        setCart((prevCart) => {
            const updatedItems = prevCart.items.filter((item) => item.id !== itemId);
            const total = updatedItems.reduce(
                (sum, item) => sum + Number(item.price) * item.quantity,
                0
            );
            return { items: updatedItems, total };
        });
    };

    const updateQuantity = (itemId: number, quantity: number) => {
        if (quantity < 1) return;
        setCart((prevCart) => {
            const updatedItems = prevCart.items.map((item) =>
                item.id === itemId ? { ...item, quantity } : item
            );
            const total = updatedItems.reduce(
                (sum, item) => sum + Number(item.price) * item.quantity,
                0
            );
            return { items: updatedItems, total };
        });
    };

    const clearCart = () => {
        setCart({ items: [], total: 0 });
    };

    return (
        <CartContext.Provider
            value={{ cart, addToCart, removeFromCart, updateQuantity, clearCart }}
        >
            {children}
        </CartContext.Provider>
    );
};

export const useCart = () => {
    const context = useContext(CartContext);
    if (context === undefined) {
        throw new Error("useCart must be used within a CartProvider");
    }
    return context;
}; 