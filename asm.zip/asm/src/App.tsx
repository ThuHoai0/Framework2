import React from "react";
import { useRoutes } from "react-router-dom";
import ClientLayout from "./layout/client";
import AdminLayout from "./layout/admin";
import Home from "./components/client/home";
import { Login } from "./pages/Login.tsx";
import { Category } from "./pages/Category.tsx";
import { ProductDetails } from "./pages/Product-details.tsx";
import { Notfound } from "./pages/Notfound.tsx";
import ProductList from "./components/admin/productlist.tsx";
import ProductAdd from "./components/admin/productadd.tsx";
import ProductEdit from "./components/admin/productedit.tsx";
import CategoryAdd from "./components/admin/categoryadd.tsx";
import CategoryEdit from "./components/admin/categoryedit.tsx";
import CategoryList from "./components/admin/categorylist.tsx";
import CategoryProducts from "./pages/CategoryProducts.tsx";
import SearchProducts from "./pages/SearchProducts.tsx";
import { Register } from "./pages/Register.tsx";
import PrivateRoute from "./middlewares/PrivateRoute.tsx";
import Cart from "./pages/Cart.tsx";
import { CartProvider } from "./context/CartContext";
import Thongke from "./components/admin/thongke.tsx";

const App = () => {
  const routes = useRoutes([
    {
      path: "/",
      element: <ClientLayout />,
      children: [
        { path: "", element: <Home /> },
        { path: "/login", element: <Login /> },
        { path: "/register", element: <Register /> },
        { path: "/cart", element: <Cart /> },
        { path: "/category", element: <Category /> },
        { path: "/category/:categoryName", element: <CategoryProducts /> },
        { path: "/search", element: <SearchProducts /> },
        { path: "/product-details/:id", element: <ProductDetails /> },
        { path: "*", element: <Notfound /> },
      ],
    },
    {
      path: "/dashboard",
      element: (
        <PrivateRoute>
          <AdminLayout />
        </PrivateRoute>
      ),
      children: [
        { path: "product-list", element: <ProductList /> },
        { path: "product-add", element: <ProductAdd /> },
        { path: "product-edit/:id", element: <ProductEdit /> },
        { path: "category-add", element: <CategoryAdd /> },
        { path: "category-edit/:id", element: <CategoryEdit /> },
        { path: "category-list", element: <CategoryList /> },
        { path: "thongke", element: <Thongke /> },
      ],
    },
  ]);
  return <CartProvider>{routes}</CartProvider>;
};

export default App;
