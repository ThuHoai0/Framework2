export interface IProduct {
  id: number;
  name: string;
  images: string;
  price: string;
  categoryID: number;
  oldPrice?: string;
  category?: string;
}