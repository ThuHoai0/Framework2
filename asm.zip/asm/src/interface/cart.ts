import { IProduct } from "./product";

export interface ICartItem extends IProduct {
    quantity: number;
}

export interface ICart {
    items: ICartItem[];
    total: number;
} 